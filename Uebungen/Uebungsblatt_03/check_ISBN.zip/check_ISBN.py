def checkISBN(digits):
    multiplicator = 9
    checksum = digits % 10
    digits //= 10
    result = 0
    while multiplicator > 0:
        a = digits % 10
        digits //= 10
        result += a* multiplicator
        multiplicator -= 1
    if checksum == result % 11:
        return True
    else:
        return False
    
print(checkISBN(1484211774))        