def ggT(a,b):
    divider = a
    if b > a:
        divider = a
    else:
        divider = b

    while divider > 0: # no exit
        if a % divider == 0 and b % divider == 0: # when the remainder of a and b modulo divider is null we have the ggT
            return divider
        divider -= 1# if not null, decrement divider

print(ggT(400, 225))

# ggT Algorithm
def optimized_ggT(a, b):
    while a != b:
        if a < b:
            b = b % a # calculating with the remainder
            if b == 0: # check if b is null, we need to return the bigger value so a
                return a
        else:
            a = a % b
            if a == 0:
                return b

print(optimized_ggT(225, 400))